//
//  sys_helper_wrapper.h
//  ProbeTool
//
//  Created by Denis Mikaya on 04.05.23.
//

#import <Foundation/Foundation.h>

#ifndef sys_helper_header_h
#define sys_helper_header_h


@interface SysHelper : NSObject

- (void) stopDebugger;
- (bool) checkDyld: (const char*) substr ;
- (int)  getDyldImageCount;
- (bool) checkDyldInserLibEnv;
@end


#endif /* sys_helper_header_h */
