//
//  UnbluCallModule.h
//  UnbluCallModule
//
//  Created by Denis on 30.07.20.
//  Copyright © 2020 Unblu inc. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for UnbluCallModule.
FOUNDATION_EXPORT double UnbluCallModuleVersionNumber;

//! Project version string for UnbluCallModule.
FOUNDATION_EXPORT const unsigned char UnbluCallModuleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UnbluCallModule/PublicHeader.h>
#import "OTDefaultAudioDevice.h"
