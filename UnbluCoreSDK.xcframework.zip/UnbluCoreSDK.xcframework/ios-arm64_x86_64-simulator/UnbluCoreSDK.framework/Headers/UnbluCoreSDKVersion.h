//
//  UnbluCoreSDKVersion.h
//  UnbluCoreSDK
//
//  Created by Denis Trüby on 24.10.17.
//  Copyright © 2017 unblu inc. All rights reserved.
//

#ifndef UnbluCoreSDKVersion_h
#define UnbluCoreSDKVersion_h

/**
 * Version of the mobile SDK
 */
#define UNBLU_MOBILE_SDK_VERSION @"4.9.2"

#endif /* UnbluCoreSDKVersion_h */
