//
//  UnbluCoreSDK.h
//  UnbluCoreSDK
//
//  Created by Denis Trüby on 11.10.16.
//  Copyright © 2016 unblu inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UnbluCoreSDK.
FOUNDATION_EXPORT double UnbluCoreSDKVersionNumber;

//! Project version string for UnbluCoreSDK.
FOUNDATION_EXPORT const unsigned char UnbluCoreSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UnbluCoreSDK/PublicHeader.h>
#import "UnbluCoreSDKVersion.h"
